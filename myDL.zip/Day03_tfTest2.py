import tensorflow as tf


ydata=[4,5,6]
xdata=[2,3,4]


tf.set_random_seed(777)


w = tf.Variable(tf.random_normal([1]), name="weight")
b = tf.Variable(tf.random_normal([1]), name="bias")

x = tf.placeholder(dtype=tf.float32,  shape=[None])
y = tf.placeholder(dtype=tf.float32,  shape=[None])



hf  = w*x + b
cost = tf.reduce_mean(tf.square(hf-y))
lr = 0.01

gradient = tf.reduce_mean((w*x-y)*x)
descent = w-lr*gradient
update = w.assign(descent)

##같은의미
#optimizer = tf.train.GradientDescentOptimizer(0.01)
#train = optimizer.minimize(cost)



sess = tf.Session()
sess.run(tf.global_variables_initializer())


for step in range(201):
    sess.run(update, feed_dict={x:xdata, y:ydata})
    print (step, sess.run([cost, w], feed_dict={x:xdata, y:ydata}))
