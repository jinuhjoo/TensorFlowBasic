import tensorflow as tf
import numpy as np
tf.set_random_seed(777)


def qRunner1():
     sess = tf.Session()
     q = tf.train.string_input_producer(['10', '20', '30'], shuffle=True)
     coord = tf.train.Coordinator()
     threads = tf.train.start_queue_runners(sess=sess, coord=coord)

     for i in range(11):
          value = sess.run(q.dequeue())
          print(value.decode('utf-8'))

     coord.request_stop()
     coord.join(threads)


def qRunner2(isshuffle):
     sess = tf.Session()
     q = tf.train.string_input_producer(['Data/q_1.txt', 'Data/q_2.txt', 'Data/q_3.txt'], shuffle=isshuffle)
     coord = tf.train.Coordinator()
     threads = tf.train.start_queue_runners(sess=sess, coord=coord)

     reader = tf.TextLineReader()
     key, value = reader.read(queue=q)


     record_defaults = [[0], [0]]
     for i in range(101):
          x, y = tf.decode_csv(value, record_defaults=record_defaults)
          print(sess.run([x, y]))

     coord.request_stop()
     coord.join(threads)


def qRunner3(batch_size=5, isshuffle=False):
     q = tf.train.string_input_producer(['Data/q_1.txt', 'Data/q_2.txt', 'Data/q_3.txt'], shuffle=isshuffle)
     reader = tf.TextLineReader()
     _, value = reader.read(queue=q)
     record_defaults = [[0], [0]]
     x, y = tf.decode_csv(value, record_defaults=record_defaults)
     xbatch, ybatch = tf.train.batch([x,y], batch_size= batch_size)


     sess = tf.Session()
     coord = tf.train.Coordinator()
     threads = tf.train.start_queue_runners(sess=sess, coord=coord)

     for i in range(101):
          x, y = sess.run([xbatch, xbatch])
          print(x,y)

     coord.request_stop()
     coord.join(threads=threads)



qRunner3(batch_size=3, isshuffle=True)