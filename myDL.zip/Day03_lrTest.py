import tensorflow as tf

w = tf.Variable([.3], tf.float32)
b = tf.Variable([-.3], tf.float32)

x = tf.placeholder(dtype=tf.float32,  shape=[None])
y = tf.placeholder(dtype=tf.float32,  shape=[None])

hf = w*x +b

loss = tf.reduce_mean(tf.square(hf-y))
optimizer = tf.train.GradientDescentOptimizer(0.01)
train = optimizer.minimize(loss)

xtrain = [1,2,3,4]
ytrain = [1,2,3,4]

sess = tf.Session()
sess.run(tf.global_variables_initializer())

for i in range(2001):
    sess.run(train, feed_dict={x:xtrain, y:ytrain})


wv, bv, lossv = sess.run([w,b,loss], feed_dict={x:xtrain, y:ytrain})

print("w:%s b:%s l:%s" % (wv, bv, lossv))




