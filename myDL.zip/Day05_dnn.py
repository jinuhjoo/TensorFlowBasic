import tensorflow as tf
import numpy as np


xdata = np.array(
            [[0,0], [1,0], [1,1], [0,0], [0,1]]
)

ydata = np.array([
            [1,0,0],
            [0,1,0],
            [0,0,1],
            [1,0,0],
            [0,0,1]
])



x=tf.placeholder(tf.float32)
y=tf.placeholder(tf.float32)

w1 = tf.Variable(tf.random_uniform( [2,10], -1., 1. ))
w2 = tf.Variable(tf.random_uniform( [10,3], -1., 1. ))

b1  =tf.Variable(tf.zeros([10]))
b2  =tf.Variable(tf.zeros([3]))


L1 = tf.add(tf.matmul(x, w1), b1)
L1 = tf.nn.relu(L1)

model = tf.add(tf.matmul(L1, w2), b2)

cost = tf.reduce_mean(
    tf.nn.softmax_cross_entropy_with_logits(logits=model, labels=y))

train = tf.train.AdamOptimizer(learning_rate=0.01).minimize(cost)




sess = tf.Session()
sess.run(tf.global_variables_initializer())

for step in range(101):
    sess.run(train, feed_dict={x:xdata, y:ydata})

    if step%10==0:
        print(step, sess.run(cost, feed_dict={x:xdata, y:ydata}))

prediction = tf.argmax(model , 1)
target = tf.argmax(y ,1)

print('predict:', sess.run(prediction, feed_dict={x:xdata}))
print('groundtruth:', sess.run(target, feed_dict={y:ydata}))

iscorrect = tf.equal(prediction, target)
accuracy = tf.reduce_mean(tf.cast(iscorrect, tf.float32))

print("acc:", accuracy)
