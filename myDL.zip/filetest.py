

def read_car():
    f= open('Data/cars.csv', 'r', encoding='utf-8')
    rows=[]

    for row in f:
        #print(row.strip().split(','))
        rows.append(row.strip().split(','))
    f.close()

    return rows


import csv
def read_tree():
    f= open('Data/trees.csv', 'r', encoding='utf-8')
    rows=[]

    for row in csv.reader(f):
        #print(row.strip().split(','))
        rows.append(row)
    f.close()

    return rows


def write_tree(rows):
    f= open('Data/treeout2.csv', 'w', encoding='utf-8', newline='')
    writer = csv.writer(f, delimiter=':')

    for row in rows:
        writer.writerows(row)
    #csv.writer(f).writerows(rows)
    f.close()




rows = read_tree()
#print(rows, sep='\n')
print(rows)

write_tree(rows)