import tensorflow as tf
import numpy as np
tf.set_random_seed(777)

xy = np.loadtxt("score.csv", delimiter=',', dtype=np.float32)
#print(xy[:])
xdata = xy[:, 0:-1]
ydata = xy[:, [-1]]
#print(ydata)


print(xdata.shape, len(xdata))
print(ydata.shape, len(ydata))


x = tf.placeholder(tf.float32, shape=[None, 3])
y = tf.placeholder(tf.float32, shape=[None, 1])

w = tf.Variable(tf.random_normal([3,1]), name='weight')
b = tf.Variable(tf.random_normal([1]), name='bias')

hf = tf.matmul(x, w) + b



cost = tf.reduce_mean(tf.square(hf-y))
optimizer  = tf.train.GradientDescentOptimizer(learning_rate=0.00001)
train = optimizer.minimize(cost)

sess = tf.Session()
sess.run(tf.global_variables_initializer())


for i in range(10001):
    c, h, _ = sess.run([cost, hf, train],
             feed_dict={x:xdata, y:ydata})

    if i%10 == 0:
        print(i, "cost:", c , "\nprediction:\n", h)


# print(sess.run(hf, feed_dict={x:[[100, 70, 95]]}))
# print(sess.run(hf, feed_dict={x:[[60, 70, 90]]}))
# print(sess.run(hf, feed_dict={x:[[80, 90, 95]]}))


print("\n예상점수:\n", sess.run(hf, feed_dict={x:[[100, 70, 95],
                                                    [60, 70, 90],
                                                    [80, 90, 95] ]}))

sess.close()



