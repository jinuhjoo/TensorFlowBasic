import tensorflow as tf
import numpy as np
tf.set_random_seed(777)

filenames = 'Data/cars.csv'






def makeBatch(filename, batch_size=5, isshuffle=False):
    q = tf.train.string_input_producer([filename], shuffle=isshuffle)
    #q = tf.train.string_input_producer(['Data/q_1.txt'], shuffle=isshuffle)
    reader = tf.TextLineReader()
    _, value = reader.read(queue=q)
    record_defaults = [[0], [0]]
    x, y = tf.decode_csv(value, record_defaults=record_defaults)
    #xy = tf.decode_csv(value, record_defaults=record_defaults)

    xbatch, ybatch = tf.train.batch([x, y], batch_size=batch_size)
    #xbatch, ybatch = tf.train.batch([xy[0:-1], xy[-1:]], batch_size=batch_size)

    return xbatch, ybatch



#qRunner3(batch_size=1, isshuffle=True)

xbatch, ybatch = makeBatch(filenames, batch_size=5, isshuffle=True)





w = tf.Variable(tf.random_normal([1]), name="weight")
b = tf.Variable(tf.random_normal([1]), name="bias")

x = tf.placeholder(dtype=tf.float32,  shape=[None, 1])
y = tf.placeholder(dtype=tf.float32,  shape=[None, 1])

hf = tf.matmul(x, w) + b


cost = tf.reduce_mean(tf.square(hf-y))
train  = tf.train.GradientDescentOptimizer(learning_rate=0.00001).minimize(cost)



sess = tf.Session()
sess.run(tf.global_variables_initializer())

coord = tf.train.Coordinator()
threads = tf.train.start_queue_runners(sess=sess, coord=coord)

for i in range(101):
    xtrain, ytrain = sess.run([xbatch, ybatch])
    #print(x, y)

    costv, hval, _ = sess.run([cost, hf, train], feed_dict={x:xtrain, y:ytrain})


coord.request_stop()
coord.join(threads=threads)


sess.close()