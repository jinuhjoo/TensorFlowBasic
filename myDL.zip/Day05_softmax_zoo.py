import tensorflow as tf
import numpy as np

tf.set_random_seed(777)


xy = np.loadtxt('Data/zoo.csv', delimiter=',', dtype=np.float32)

xdata = xy[:, 0:-1]
ydata = xy[:, [-1]]

print(xdata.shape, ydata.shape)

nb_classes = 7

x = tf.placeholder(tf.float32, [None, 16])
y = tf.placeholder(tf.int32, [None, 1])

yonehot = tf.one_hot(y, nb_classes)
print(yonehot.shape)

yonehot = tf.reshape(yonehot, [-1, 7])
print(yonehot.shape)

w = tf.Variable(tf.random_normal([16, nb_classes]))
b = tf.Variable(tf.random_normal([nb_classes]))


logits = tf.matmul(x,y) + b
hf = tf.nn.softmax(logits)

costi = tf.nn.softmax_cross_entropy_with_logits(logits=logits, labels=yonehot)
cost = tf.reduce_mean(costi)

train = tf.train.GradientDescentOptimizer(learning_rate=0.1).minimize(cost)

prediction = tf.argmax(hf,1) #axis=1
correct_prediction = tf.equal( prediction, tf.argmax(yonehot,1) )

accuracy = tf.reduce_mean(tf.cast(correct_prediction, dtype=tf.float32))

sess = tf.Session()
sess.run(tf.global_variables_initializer())

for step in range(2001):
    sess.run(train, feed_dict={x:xdata, y:ydata})
    if step%100==0:
        cv, av = sess.run([cost, accuracy], feed_dict={x:xdata, y:ydata})
        print("step: {:5}\tcost:{:.3f}\tacc:{:2%}".format(step,cv,av))

pred = sess.run(prediction, feed_dict={x:xdata})
for p,y in zip(pred, ydata.flatten()):
    print("[{}]")


